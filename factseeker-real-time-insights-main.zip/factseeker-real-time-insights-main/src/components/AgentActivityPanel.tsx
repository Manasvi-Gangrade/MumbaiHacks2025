import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Bot, Search, Shield, Bell } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

interface ActivityLog {
  id: string;
  agent: "detection" | "verification" | "alert";
  action: string;
  timestamp: string;
  status: "active" | "completed";
}

const mockLogs: ActivityLog[] = [
  {
    id: "1",
    agent: "detection",
    action: "Analyzed 47 posts from Twitter/X",
    timestamp: "2 min ago",
    status: "completed",
  },
  {
    id: "2",
    agent: "verification",
    action: "Cross-checking sources for flagged content",
    timestamp: "3 min ago",
    status: "active",
  },
  {
    id: "3",
    agent: "alert",
    action: "Sent high-priority alert to 3 channels",
    timestamp: "5 min ago",
    status: "completed",
  },
  {
    id: "4",
    agent: "detection",
    action: "Processing multimodal content",
    timestamp: "7 min ago",
    status: "completed",
  },
  {
    id: "5",
    agent: "verification",
    action: "RAG verification against trusted sources",
    timestamp: "8 min ago",
    status: "completed",
  },
];

const agentConfig = {
  detection: {
    icon: Search,
    label: "Detection Agent",
    color: "text-primary",
  },
  verification: {
    icon: Shield,
    label: "Verification Agent",
    color: "text-success",
  },
  alert: {
    icon: Bell,
    label: "Alert Agent",
    color: "text-warning",
  },
};

export const AgentActivityPanel = () => {
  return (
    <Card className="p-6 bg-card border border-border">
      <div className="flex items-center gap-3 mb-6">
        <Bot className="h-6 w-6 text-primary" />
        <h2 className="text-xl font-orbitron font-bold text-foreground">
          Multi-Agent Activity
        </h2>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-6">
        {Object.entries(agentConfig).map(([key, config]) => (
          <div
            key={key}
            className="p-4 bg-secondary/30 rounded-lg border border-border"
          >
            <div className="flex items-center gap-2 mb-2">
              <config.icon className={`h-5 w-5 ${config.color}`} />
              <Badge variant="outline" className="text-xs">
                Active
              </Badge>
            </div>
            <p className="text-xs font-sans text-muted-foreground">
              {config.label}
            </p>
          </div>
        ))}
      </div>

      <ScrollArea className="h-[300px] pr-4">
        <div className="space-y-3">
          {mockLogs.map((log) => {
            const config = agentConfig[log.agent];
            const AgentIcon = config.icon;

            return (
              <div
                key={log.id}
                className="flex items-start gap-3 p-3 bg-secondary/20 rounded-lg border border-border/50 hover:border-primary/30 transition-colors"
              >
                <div className="p-2 bg-card rounded-lg">
                  <AgentIcon className={`h-4 w-4 ${config.color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-sans text-foreground">
                    {log.action}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {config.label} • {log.timestamp}
                  </p>
                </div>
                {log.status === "active" && (
                  <div className="h-2 w-2 bg-primary rounded-full animate-pulse-glow" />
                )}
              </div>
            );
          })}
        </div>
      </ScrollArea>
    </Card>
  );
};
