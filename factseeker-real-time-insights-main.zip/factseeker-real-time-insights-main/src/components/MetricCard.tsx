import { LucideIcon } from "lucide-react";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface MetricCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  trend?: {
    value: string;
    isPositive: boolean;
  };
  variant?: "default" | "success" | "warning" | "destructive";
}

export const MetricCard = ({
  title,
  value,
  icon: Icon,
  trend,
  variant = "default",
}: MetricCardProps) => {
  const variantStyles = {
    default: "border-primary/30 hover:border-primary/50",
    success: "border-success/30 hover:border-success/50",
    warning: "border-warning/30 hover:border-warning/50",
    destructive: "border-destructive/30 hover:border-destructive/50",
  };

  const iconStyles = {
    default: "text-primary",
    success: "text-success",
    warning: "text-warning",
    destructive: "text-destructive",
  };

  return (
    <Card
      className={cn(
        "p-6 bg-card border-2 transition-all duration-300 hover:scale-[1.02] cursor-pointer",
        variantStyles[variant]
      )}
    >
      <div className="flex items-start justify-between">
        <div className="space-y-2 flex-1">
          <p className="text-sm font-sans text-muted-foreground">{title}</p>
          <p className="text-3xl font-orbitron font-bold text-foreground">
            {value}
          </p>
          {trend && (
            <p
              className={cn(
                "text-xs font-sans",
                trend.isPositive ? "text-success" : "text-destructive"
              )}
            >
              {trend.value}
            </p>
          )}
        </div>
        <div
          className={cn(
            "p-3 rounded-lg bg-secondary/50",
            iconStyles[variant]
          )}
        >
          <Icon className="h-6 w-6" />
        </div>
      </div>
    </Card>
  );
};
