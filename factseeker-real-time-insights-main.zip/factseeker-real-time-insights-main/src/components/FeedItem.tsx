import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, CheckCircle, Clock, Eye } from "lucide-react";
import { cn } from "@/lib/utils";

export interface FeedItemData {
  id: string;
  platform: string;
  content: string;
  author: string;
  timestamp: string;
  status: "flagged" | "verified" | "under_review";
  confidence: number;
  contentType: "text" | "image" | "video";
}

interface FeedItemProps {
  item: FeedItemData;
  onClick?: () => void;
}

export const FeedItem = ({ item, onClick }: FeedItemProps) => {
  const statusConfig = {
    flagged: {
      icon: AlertTriangle,
      color: "text-destructive",
      bgColor: "bg-destructive/10",
      label: "Flagged",
    },
    verified: {
      icon: CheckCircle,
      color: "text-success",
      bgColor: "bg-success/10",
      label: "Verified",
    },
    under_review: {
      icon: Clock,
      color: "text-warning",
      bgColor: "bg-warning/10",
      label: "Under Review",
    },
  };

  const config = statusConfig[item.status];
  const StatusIcon = config.icon;

  return (
    <Card
      className="p-4 bg-card border border-border hover:border-primary/50 transition-all duration-200 cursor-pointer animate-slide-in"
      onClick={onClick}
    >
      <div className="flex items-start gap-4">
        <div className={cn("p-2 rounded-lg", config.bgColor)}>
          <StatusIcon className={cn("h-5 w-5", config.color)} />
        </div>

        <div className="flex-1 space-y-2">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="outline" className="text-xs">
              {item.platform}
            </Badge>
            <Badge variant="outline" className="text-xs">
              {item.contentType}
            </Badge>
            <span className="text-xs text-muted-foreground">
              by {item.author}
            </span>
            <span className="text-xs text-muted-foreground">•</span>
            <span className="text-xs text-muted-foreground">
              {item.timestamp}
            </span>
          </div>

          <p className="text-sm font-sans text-foreground line-clamp-2">
            {item.content}
          </p>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className={cn("text-xs font-medium", config.color)}>
                {config.label}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Eye className="h-4 w-4 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">
                Confidence: {item.confidence}%
              </span>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
};
