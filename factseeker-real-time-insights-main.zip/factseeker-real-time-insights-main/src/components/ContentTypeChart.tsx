import { Card } from "@/components/ui/card";
import { PieChart } from "lucide-react";
import {
  PieChart as RechartPieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Legend,
  Tooltip,
} from "recharts";

const data = [
  { name: "Text", value: 450 },
  { name: "Image", value: 280 },
  { name: "Video", value: 150 },
  { name: "Audio", value: 80 },
];

const COLORS = [
  "hsl(189 94% 43%)", // cyan
  "hsl(142 76% 36%)", // green
  "hsl(38 92% 50%)", // yellow
  "hsl(0 84% 60%)", // red
];

export const ContentTypeChart = () => {
  return (
    <Card className="p-6 bg-card border border-border">
      <div className="flex items-center gap-3 mb-6">
        <PieChart className="h-6 w-6 text-primary" />
        <h2 className="text-xl font-orbitron font-bold text-foreground">
          Content Types
        </h2>
      </div>

      <ResponsiveContainer width="100%" height={300}>
        <RechartPieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            labelLine={false}
            label={({ name, percent }) =>
              `${name}: ${(percent * 100).toFixed(0)}%`
            }
            outerRadius={100}
            fill="#8884d8"
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={COLORS[index % COLORS.length]}
              />
            ))}
          </Pie>
          <Tooltip
            contentStyle={{
              backgroundColor: "hsl(var(--card))",
              border: "1px solid hsl(var(--border))",
              borderRadius: "8px",
              color: "hsl(var(--foreground))",
            }}
          />
          <Legend
            wrapperStyle={{
              fontSize: "12px",
              color: "hsl(var(--foreground))",
            }}
          />
        </RechartPieChart>
      </ResponsiveContainer>
    </Card>
  );
};
