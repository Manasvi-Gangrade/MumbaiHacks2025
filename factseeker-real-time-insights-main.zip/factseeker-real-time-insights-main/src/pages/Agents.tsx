import { Sidebar } from "@/components/Sidebar";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Bot, Search, Shield, Bell, Activity, Settings as SettingsIcon } from "lucide-react";

const agentData = [
  {
    name: "Detection Agent",
    icon: Search,
    color: "text-primary",
    bgColor: "bg-primary/10",
    status: "active",
    description: "Monitors and analyzes content across multiple platforms using multimodal AI models",
    metrics: {
      postsAnalyzed: "12,456",
      accuracy: "94.2%",
      avgResponseTime: "1.2s",
    },
    capabilities: [
      "Text analysis with BERT/RoBERTa",
      "Image detection with ViT/CNN",
      "Video analysis with Transformer models",
      "Audio processing with Whisper",
    ],
  },
  {
    name: "Verification Agent",
    icon: Shield,
    color: "text-success",
    bgColor: "bg-success/10",
    status: "active",
    description: "Cross-references flagged content against trusted sources using RAG technology",
    metrics: {
      claimsVerified: "1,234",
      accuracy: "96.8%",
      avgResponseTime: "2.8s",
    },
    capabilities: [
      "RAG-based fact-checking",
      "Source credibility assessment",
      "Multi-source verification",
      "LLM-powered analysis",
    ],
  },
  {
    name: "Alert Agent",
    icon: Bell,
    color: "text-warning",
    bgColor: "bg-warning/10",
    status: "active",
    description: "Manages alert distribution and notification delivery across multiple channels",
    metrics: {
      alertsSent: "847",
      deliveryRate: "99.1%",
      avgDeliveryTime: "0.5s",
    },
    capabilities: [
      "Multi-channel notifications",
      "Priority-based routing",
      "GenAI summaries",
      "Multi-lingual support",
    ],
  },
];

const Agents = () => {
  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar />
      
      <main className="flex-1 ml-64 p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-orbitron font-bold text-foreground mb-2">
                Multi-Agent System
              </h1>
              <p className="text-muted-foreground font-sans">
                Monitor and manage AI agents orchestrating the detection pipeline
              </p>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 bg-success rounded-full animate-pulse-glow" />
              <span className="text-sm text-muted-foreground font-sans">
                All Agents Active
              </span>
            </div>
          </div>

          {/* Agent Workflow Diagram */}
          <Card className="p-8 bg-card border border-border">
            <h2 className="text-2xl font-orbitron font-bold text-foreground mb-6">
              Agent Workflow Pipeline
            </h2>
            
            <div className="flex items-center justify-center gap-8">
              <div className="flex flex-col items-center">
                <div className="h-24 w-24 rounded-full bg-primary/20 border-2 border-primary flex items-center justify-center glow-cyan">
                  <Search className="h-12 w-12 text-primary" />
                </div>
                <p className="text-sm font-orbitron font-semibold text-foreground mt-3">
                  Detection
                </p>
              </div>

              <div className="flex-1 h-1 bg-gradient-to-r from-primary to-success" />

              <div className="flex flex-col items-center">
                <div className="h-24 w-24 rounded-full bg-success/20 border-2 border-success flex items-center justify-center">
                  <Shield className="h-12 w-12 text-success" />
                </div>
                <p className="text-sm font-orbitron font-semibold text-foreground mt-3">
                  Verification
                </p>
              </div>

              <div className="flex-1 h-1 bg-gradient-to-r from-success to-warning" />

              <div className="flex flex-col items-center">
                <div className="h-24 w-24 rounded-full bg-warning/20 border-2 border-warning flex items-center justify-center">
                  <Bell className="h-12 w-12 text-warning" />
                </div>
                <p className="text-sm font-orbitron font-semibold text-foreground mt-3">
                  Alert
                </p>
              </div>
            </div>
          </Card>

          {/* Agent Cards */}
          <div className="space-y-6">
            {agentData.map((agent) => {
              const AgentIcon = agent.icon;
              return (
                <Card
                  key={agent.name}
                  className="p-8 bg-card border-2 border-border hover:border-primary/50 transition-all duration-200"
                >
                  <div className="space-y-6">
                    {/* Agent Header */}
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-4">
                        <div className={`h-16 w-16 rounded-2xl ${agent.bgColor} flex items-center justify-center`}>
                          <AgentIcon className={`h-8 w-8 ${agent.color}`} />
                        </div>
                        <div>
                          <h3 className="text-2xl font-orbitron font-bold text-foreground">
                            {agent.name}
                          </h3>
                          <p className="text-sm font-sans text-muted-foreground mt-1">
                            {agent.description}
                          </p>
                        </div>
                      </div>
                      
                      <Badge variant="outline" className="text-success border-success">
                        <Activity className="h-3 w-3 mr-1" />
                        {agent.status}
                      </Badge>
                    </div>

                    {/* Metrics Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {Object.entries(agent.metrics).map(([key, value]) => (
                        <div
                          key={key}
                          className="p-4 bg-secondary/30 rounded-lg border border-border"
                        >
                          <p className="text-xs text-muted-foreground font-sans mb-1">
                            {key.replace(/([A-Z])/g, ' $1').trim()}
                          </p>
                          <p className="text-2xl font-orbitron font-bold text-foreground">
                            {value}
                          </p>
                        </div>
                      ))}
                    </div>

                    {/* Capabilities */}
                    <div>
                      <h4 className="text-sm font-orbitron font-semibold text-foreground mb-3">
                        Capabilities
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {agent.capabilities.map((capability) => (
                          <div
                            key={capability}
                            className="flex items-center gap-2 p-3 bg-secondary/20 rounded-lg border border-border/50"
                          >
                            <div className={`h-2 w-2 rounded-full ${agent.color.replace('text-', 'bg-')}`} />
                            <span className="text-sm font-sans text-foreground">
                              {capability}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
      </main>
    </div>
  );
};

export default Agents;
