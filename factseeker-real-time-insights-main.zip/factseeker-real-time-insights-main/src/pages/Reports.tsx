import { Sidebar } from "@/components/Sidebar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, FileText, TrendingUp, AlertTriangle } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const reportData = [
  {
    id: "1",
    title: "Daily Misinformation Summary",
    description: "Comprehensive analysis of flagged content and verification results",
    date: "2024-01-26",
    type: "Daily",
    status: "Ready",
    metrics: {
      totalPosts: "12,456",
      flagged: "847",
      verified: "1,234",
    },
  },
  {
    id: "2",
    title: "Weekly Trend Analysis",
    description: "Trending misinformation narratives and platform analysis",
    date: "2024-01-20",
    type: "Weekly",
    status: "Ready",
    metrics: {
      totalPosts: "87,234",
      flagged: "5,891",
      verified: "8,432",
    },
  },
  {
    id: "3",
    title: "High-Risk Alert Report",
    description: "Critical alerts and high-priority content analysis",
    date: "2024-01-26",
    type: "Alert-Based",
    status: "Ready",
    metrics: {
      highRisk: "23",
      mediumRisk: "145",
      lowRisk: "679",
    },
  },
  {
    id: "4",
    title: "Agent Performance Report",
    description: "Multi-agent system performance metrics and efficiency analysis",
    date: "2024-01-25",
    type: "System",
    status: "Ready",
    metrics: {
      accuracy: "94.2%",
      responseTime: "1.5s",
      uptime: "99.9%",
    },
  },
];

const Reports = () => {
  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar />
      
      <main className="flex-1 ml-64 p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-orbitron font-bold text-foreground mb-2">
                Reports
              </h1>
              <p className="text-muted-foreground font-sans">
                Export and analyze detection reports and system metrics
              </p>
            </div>
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Download className="h-4 w-4 mr-2" />
              Export All
            </Button>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card className="p-6 bg-card border-2 border-primary/30">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-sans text-muted-foreground">Reports Generated</p>
                  <p className="text-3xl font-orbitron font-bold text-foreground mt-2">
                    {reportData.length}
                  </p>
                </div>
                <FileText className="h-8 w-8 text-primary" />
              </div>
            </Card>
            
            <Card className="p-6 bg-card border-2 border-success/30">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-sans text-muted-foreground">Total Analyzed</p>
                  <p className="text-3xl font-orbitron font-bold text-foreground mt-2">
                    99,690
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 text-success" />
              </div>
            </Card>
            
            <Card className="p-6 bg-card border-2 border-warning/30">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-sans text-muted-foreground">Total Flagged</p>
                  <p className="text-3xl font-orbitron font-bold text-foreground mt-2">
                    6,738
                  </p>
                </div>
                <AlertTriangle className="h-8 w-8 text-warning" />
              </div>
            </Card>
            
            <Card className="p-6 bg-card border-2 border-destructive/30">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-sans text-muted-foreground">High-Risk</p>
                  <p className="text-3xl font-orbitron font-bold text-foreground mt-2">
                    23
                  </p>
                </div>
                <AlertTriangle className="h-8 w-8 text-destructive" />
              </div>
            </Card>
          </div>

          {/* Reports List */}
          <div className="space-y-4">
            {reportData.map((report) => (
              <Card
                key={report.id}
                className="p-6 bg-card border border-border hover:border-primary/50 transition-all duration-200"
              >
                <div className="flex items-start justify-between gap-6">
                  <div className="flex-1 space-y-4">
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <FileText className="h-5 w-5 text-primary" />
                        <h3 className="text-xl font-orbitron font-bold text-foreground">
                          {report.title}
                        </h3>
                      </div>
                      <p className="text-sm font-sans text-muted-foreground">
                        {report.description}
                      </p>
                    </div>

                    <div className="flex items-center gap-4 flex-wrap">
                      <Badge variant="outline">
                        {report.type}
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        Generated: {report.date}
                      </span>
                      <Badge variant="outline" className="text-success border-success">
                        {report.status}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      {Object.entries(report.metrics).map(([key, value]) => (
                        <div
                          key={key}
                          className="p-3 bg-secondary/30 rounded-lg border border-border"
                        >
                          <p className="text-xs text-muted-foreground font-sans mb-1">
                            {key.replace(/([A-Z])/g, ' $1').trim()}
                          </p>
                          <p className="text-lg font-orbitron font-bold text-foreground">
                            {value}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      CSV
                    </Button>
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      JSON
                    </Button>
                    <Button variant="outline" size="sm">
                      View
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
};

export default Reports;
