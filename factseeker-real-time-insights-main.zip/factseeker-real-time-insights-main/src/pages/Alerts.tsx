import { Sidebar } from "@/components/Sidebar";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { AlertTriangle, Bell, CheckCircle, Clock, Filter } from "lucide-react";
import { useState } from "react";

interface Alert {
  id: string;
  title: string;
  description: string;
  severity: "high" | "medium" | "low";
  platform: string;
  timestamp: string;
  status: "new" | "acknowledged" | "resolved";
  confidence: number;
}

const mockAlerts: Alert[] = [
  {
    id: "1",
    title: "High-Risk Election Misinformation Detected",
    description: "Coordinated spread of false claims about voting procedures detected across multiple platforms with high virality potential.",
    severity: "high",
    platform: "Twitter/X, Facebook",
    timestamp: "5 min ago",
    status: "new",
    confidence: 94,
  },
  {
    id: "2",
    title: "Deepfake Video Spreading Rapidly",
    description: "AI-generated video featuring public figure detected with strong deepfake signatures. Currently trending on social media.",
    severity: "high",
    platform: "TikTok",
    timestamp: "12 min ago",
    status: "acknowledged",
    confidence: 91,
  },
  {
    id: "3",
    title: "Misleading Health Claims Flagged",
    description: "Unverified medical advice spreading in health communities. Requires fact-checking against trusted sources.",
    severity: "medium",
    platform: "Reddit, WhatsApp",
    timestamp: "28 min ago",
    status: "acknowledged",
    confidence: 87,
  },
  {
    id: "4",
    title: "Disputed News Article Verified",
    description: "Previously flagged article has been cross-referenced with multiple trusted sources and verified as accurate.",
    severity: "low",
    platform: "Twitter/X",
    timestamp: "1 hour ago",
    status: "resolved",
    confidence: 96,
  },
];

const Alerts = () => {
  const [filter, setFilter] = useState<"all" | "high" | "medium" | "low">("all");

  const severityConfig = {
    high: {
      color: "text-destructive",
      bgColor: "bg-destructive/10",
      borderColor: "border-destructive/50",
    },
    medium: {
      color: "text-warning",
      bgColor: "bg-warning/10",
      borderColor: "border-warning/50",
    },
    low: {
      color: "text-success",
      bgColor: "bg-success/10",
      borderColor: "border-success/50",
    },
  };

  const statusConfig = {
    new: { label: "New", icon: Bell, color: "text-primary" },
    acknowledged: { label: "Acknowledged", icon: Clock, color: "text-warning" },
    resolved: { label: "Resolved", icon: CheckCircle, color: "text-success" },
  };

  const filteredAlerts = filter === "all" 
    ? mockAlerts 
    : mockAlerts.filter(alert => alert.severity === filter);

  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar />
      
      <main className="flex-1 ml-64 p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-orbitron font-bold text-foreground mb-2">
                Alerts
              </h1>
              <p className="text-muted-foreground font-sans">
                Real-time alerts and notifications for high-priority content
              </p>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Filter className="h-5 w-5 text-muted-foreground" />
                <select
                  value={filter}
                  onChange={(e) => setFilter(e.target.value as typeof filter)}
                  className="bg-card border border-border rounded-lg px-4 py-2 text-sm font-sans text-foreground"
                >
                  <option value="all">All Severities</option>
                  <option value="high">High</option>
                  <option value="medium">Medium</option>
                  <option value="low">Low</option>
                </select>
              </div>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card className="p-6 bg-card border-2 border-destructive/30">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-sans text-muted-foreground">High Priority</p>
                  <p className="text-3xl font-orbitron font-bold text-destructive mt-2">
                    {mockAlerts.filter(a => a.severity === "high").length}
                  </p>
                </div>
                <AlertTriangle className="h-8 w-8 text-destructive" />
              </div>
            </Card>
            
            <Card className="p-6 bg-card border-2 border-warning/30">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-sans text-muted-foreground">Medium Priority</p>
                  <p className="text-3xl font-orbitron font-bold text-warning mt-2">
                    {mockAlerts.filter(a => a.severity === "medium").length}
                  </p>
                </div>
                <Clock className="h-8 w-8 text-warning" />
              </div>
            </Card>
            
            <Card className="p-6 bg-card border-2 border-primary/30">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-sans text-muted-foreground">New Alerts</p>
                  <p className="text-3xl font-orbitron font-bold text-primary mt-2">
                    {mockAlerts.filter(a => a.status === "new").length}
                  </p>
                </div>
                <Bell className="h-8 w-8 text-primary" />
              </div>
            </Card>
            
            <Card className="p-6 bg-card border-2 border-success/30">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-sans text-muted-foreground">Resolved</p>
                  <p className="text-3xl font-orbitron font-bold text-success mt-2">
                    {mockAlerts.filter(a => a.status === "resolved").length}
                  </p>
                </div>
                <CheckCircle className="h-8 w-8 text-success" />
              </div>
            </Card>
          </div>

          {/* Alerts List */}
          <Card className="p-6 bg-card border border-border">
            <h2 className="text-2xl font-orbitron font-bold text-foreground mb-6">
              Alert Feed
            </h2>
            
            <ScrollArea className="h-[600px] pr-4">
              <div className="space-y-4">
                {filteredAlerts.map((alert) => {
                  const severityStyle = severityConfig[alert.severity];
                  const statusInfo = statusConfig[alert.status];
                  const StatusIcon = statusInfo.icon;

                  return (
                    <Card
                      key={alert.id}
                      className={`p-6 border-2 ${severityStyle.borderColor} ${severityStyle.bgColor} hover:scale-[1.01] transition-all duration-200`}
                    >
                      <div className="space-y-4">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <AlertTriangle className={`h-5 w-5 ${severityStyle.color}`} />
                              <h3 className="text-lg font-orbitron font-semibold text-foreground">
                                {alert.title}
                              </h3>
                            </div>
                            <p className="text-sm font-sans text-muted-foreground mb-3">
                              {alert.description}
                            </p>
                          </div>
                          
                          <Badge
                            variant="outline"
                            className={`uppercase text-xs font-bold ${severityStyle.color}`}
                          >
                            {alert.severity}
                          </Badge>
                        </div>

                        <div className="flex items-center gap-4 flex-wrap">
                          <div className="flex items-center gap-2">
                            <StatusIcon className={`h-4 w-4 ${statusInfo.color}`} />
                            <span className="text-xs font-sans text-muted-foreground">
                              {statusInfo.label}
                            </span>
                          </div>
                          
                          <Badge variant="outline" className="text-xs">
                            {alert.platform}
                          </Badge>
                          
                          <span className="text-xs text-muted-foreground">
                            Confidence: {alert.confidence}%
                          </span>
                          
                          <span className="text-xs text-muted-foreground">
                            {alert.timestamp}
                          </span>
                        </div>

                        <div className="flex gap-2">
                          {alert.status === "new" && (
                            <Button size="sm" variant="outline">
                              Acknowledge
                            </Button>
                          )}
                          {alert.status === "acknowledged" && (
                            <Button size="sm" variant="outline">
                              Mark Resolved
                            </Button>
                          )}
                          <Button size="sm" variant="ghost">
                            View Details
                          </Button>
                        </div>
                      </div>
                    </Card>
                  );
                })}
              </div>
            </ScrollArea>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default Alerts;
