import { Sidebar } from "@/components/Sidebar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Settings as SettingsIcon, Bell, Database, Zap, Shield } from "lucide-react";

const Settings = () => {
  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar />
      
      <main className="flex-1 ml-64 p-8">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Header */}
          <div>
            <h1 className="text-4xl font-orbitron font-bold text-foreground mb-2">
              Settings
            </h1>
            <p className="text-muted-foreground font-sans">
              Configure system behavior and agent parameters
            </p>
          </div>

          {/* Notification Settings */}
          <Card className="p-6 bg-card border border-border">
            <div className="flex items-center gap-3 mb-6">
              <Bell className="h-6 w-6 text-primary" />
              <h2 className="text-2xl font-orbitron font-bold text-foreground">
                Notification Settings
              </h2>
            </div>

            <div className="space-y-6">
              <div className="flex items-center justify-between p-4 bg-secondary/20 rounded-lg border border-border">
                <div className="space-y-1">
                  <Label htmlFor="high-priority" className="text-base font-sans">
                    High-Priority Alerts
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    Receive immediate notifications for high-risk content
                  </p>
                </div>
                <Switch id="high-priority" defaultChecked />
              </div>

              <div className="flex items-center justify-between p-4 bg-secondary/20 rounded-lg border border-border">
                <div className="space-y-1">
                  <Label htmlFor="email-notifications" className="text-base font-sans">
                    Email Notifications
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    Send daily summary reports via email
                  </p>
                </div>
                <Switch id="email-notifications" defaultChecked />
              </div>

              <div className="flex items-center justify-between p-4 bg-secondary/20 rounded-lg border border-border">
                <div className="space-y-1">
                  <Label htmlFor="telegram" className="text-base font-sans">
                    Telegram Integration
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    Push alerts to Telegram channel
                  </p>
                </div>
                <Switch id="telegram" />
              </div>

              <div className="flex items-center justify-between p-4 bg-secondary/20 rounded-lg border border-border">
                <div className="space-y-1">
                  <Label htmlFor="whatsapp" className="text-base font-sans">
                    WhatsApp Integration
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    Send alerts via WhatsApp Business API
                  </p>
                </div>
                <Switch id="whatsapp" />
              </div>
            </div>
          </Card>

          {/* Detection Settings */}
          <Card className="p-6 bg-card border border-border">
            <div className="flex items-center gap-3 mb-6">
              <Zap className="h-6 w-6 text-primary" />
              <h2 className="text-2xl font-orbitron font-bold text-foreground">
                Detection Settings
              </h2>
            </div>

            <div className="space-y-6">
              <div className="space-y-3">
                <Label htmlFor="confidence-threshold" className="text-base font-sans">
                  Confidence Threshold
                </Label>
                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    id="confidence-threshold"
                    min="50"
                    max="100"
                    defaultValue="75"
                    className="flex-1"
                  />
                  <Badge variant="outline" className="text-primary border-primary">
                    75%
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  Minimum confidence level to flag content as misinformation
                </p>
              </div>

              <div className="flex items-center justify-between p-4 bg-secondary/20 rounded-lg border border-border">
                <div className="space-y-1">
                  <Label htmlFor="multimodal" className="text-base font-sans">
                    Multimodal Analysis
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    Analyze text, images, video, and audio content
                  </p>
                </div>
                <Switch id="multimodal" defaultChecked />
              </div>

              <div className="flex items-center justify-between p-4 bg-secondary/20 rounded-lg border border-border">
                <div className="space-y-1">
                  <Label htmlFor="real-time" className="text-base font-sans">
                    Real-Time Processing
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    Process content as it arrives (may increase resource usage)
                  </p>
                </div>
                <Switch id="real-time" defaultChecked />
              </div>
            </div>
          </Card>

          {/* Data Sources */}
          <Card className="p-6 bg-card border border-border">
            <div className="flex items-center gap-3 mb-6">
              <Database className="h-6 w-6 text-primary" />
              <h2 className="text-2xl font-orbitron font-bold text-foreground">
                Data Sources
              </h2>
            </div>

            <div className="space-y-4">
              {["Twitter/X", "Reddit", "Facebook", "WhatsApp", "NewsAPI"].map((source) => (
                <div
                  key={source}
                  className="flex items-center justify-between p-4 bg-secondary/20 rounded-lg border border-border"
                >
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-lg bg-primary/20 flex items-center justify-center">
                      <Database className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-sans font-medium text-foreground">{source}</p>
                      <Badge variant="outline" className="text-success border-success mt-1">
                        Connected
                      </Badge>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    Configure
                  </Button>
                </div>
              ))}
            </div>
          </Card>

          {/* Security */}
          <Card className="p-6 bg-card border border-border">
            <div className="flex items-center gap-3 mb-6">
              <Shield className="h-6 w-6 text-primary" />
              <h2 className="text-2xl font-orbitron font-bold text-foreground">
                Security & Privacy
              </h2>
            </div>

            <div className="space-y-6">
              <div className="flex items-center justify-between p-4 bg-secondary/20 rounded-lg border border-border">
                <div className="space-y-1">
                  <Label htmlFor="data-encryption" className="text-base font-sans">
                    Data Encryption
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    Encrypt all stored data and communications
                  </p>
                </div>
                <Switch id="data-encryption" defaultChecked />
              </div>

              <div className="flex items-center justify-between p-4 bg-secondary/20 rounded-lg border border-border">
                <div className="space-y-1">
                  <Label htmlFor="anonymize" className="text-base font-sans">
                    Anonymize User Data
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    Remove personally identifiable information from analysis
                  </p>
                </div>
                <Switch id="anonymize" defaultChecked />
              </div>
            </div>
          </Card>

          {/* Save Button */}
          <div className="flex justify-end gap-4">
            <Button variant="outline">
              Reset to Defaults
            </Button>
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
              <SettingsIcon className="h-4 w-4 mr-2" />
              Save Changes
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Settings;
