import { Sidebar } from "@/components/Sidebar";
import { MetricCard } from "@/components/MetricCard";
import { FeedItem, FeedItemData } from "@/components/FeedItem";
import { AgentActivityPanel } from "@/components/AgentActivityPanel";
import { TrendChart } from "@/components/TrendChart";
import { ContentTypeChart } from "@/components/ContentTypeChart";
import { FileText, AlertTriangle, CheckCircle, TrendingUp } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useState, useEffect } from "react";

const mockFeedData: FeedItemData[] = [
  {
    id: "1",
    platform: "Twitter/X",
    content:
      "BREAKING: Unverified claims about election fraud spreading rapidly across social media platforms...",
    author: "@newsaccount",
    timestamp: "2 min ago",
    status: "flagged",
    confidence: 87,
    contentType: "text",
  },
  {
    id: "2",
    platform: "Reddit",
    content:
      "Fact-checked: The recent health study has been verified by multiple independent sources...",
    author: "u/factchecker",
    timestamp: "5 min ago",
    status: "verified",
    confidence: 95,
    contentType: "text",
  },
  {
    id: "3",
    platform: "WhatsApp",
    content:
      "Viral image claiming to show disaster scene requires verification from multiple sources...",
    author: "+1234567890",
    timestamp: "12 min ago",
    status: "under_review",
    confidence: 72,
    contentType: "image",
  },
  {
    id: "4",
    platform: "Twitter/X",
    content:
      "Video showing alleged government conspiracy detected with AI deepfake signatures...",
    author: "@anonymoususer",
    timestamp: "18 min ago",
    status: "flagged",
    confidence: 91,
    contentType: "video",
  },
];

const Index = () => {
  const [feedItems, setFeedItems] = useState<FeedItemData[]>([]);

  useEffect(() => {
    // Simulate real-time feed updates
    setFeedItems(mockFeedData);
    
    const interval = setInterval(() => {
      // Simulate new items appearing
      const newItem: FeedItemData = {
        id: Date.now().toString(),
        platform: ["Twitter/X", "Reddit", "WhatsApp"][Math.floor(Math.random() * 3)],
        content: "New content detected and being analyzed by detection agents...",
        author: "@newuser",
        timestamp: "Just now",
        status: "under_review",
        confidence: Math.floor(Math.random() * 30) + 70,
        contentType: ["text", "image", "video"][Math.floor(Math.random() * 3)] as "text" | "image" | "video",
      };
      
      setFeedItems(prev => [newItem, ...prev].slice(0, 10));
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar />
      
      <main className="flex-1 ml-64 p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-orbitron font-bold text-foreground mb-2">
                Dashboard
              </h1>
              <p className="text-muted-foreground font-sans">
                Real-time misinformation monitoring and detection
              </p>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 bg-success rounded-full animate-pulse-glow" />
              <span className="text-sm text-muted-foreground font-sans">
                Live
              </span>
            </div>
          </div>

          {/* Metrics Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <MetricCard
              title="Total Posts Analyzed"
              value="12,456"
              icon={FileText}
              trend={{ value: "+12% from yesterday", isPositive: true }}
            />
            <MetricCard
              title="Flagged Content"
              value="847"
              icon={AlertTriangle}
              variant="warning"
              trend={{ value: "+8% from yesterday", isPositive: false }}
            />
            <MetricCard
              title="Verified Claims"
              value="1,234"
              icon={CheckCircle}
              variant="success"
              trend={{ value: "+15% from yesterday", isPositive: true }}
            />
            <MetricCard
              title="High-Risk Alerts"
              value="23"
              icon={TrendingUp}
              variant="destructive"
              trend={{ value: "+3 in last hour", isPositive: false }}
            />
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Feed Column */}
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-card border border-border rounded-lg p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-orbitron font-bold text-foreground">
                    Live Content Feed
                  </h2>
                  <span className="text-sm text-muted-foreground font-sans">
                    {feedItems.length} items
                  </span>
                </div>
                
                <ScrollArea className="h-[600px] pr-4">
                  <div className="space-y-4">
                    {feedItems.map((item) => (
                      <FeedItem key={item.id} item={item} />
                    ))}
                  </div>
                </ScrollArea>
              </div>
            </div>

            {/* Side Panels */}
            <div className="space-y-6">
              <AgentActivityPanel />
            </div>
          </div>

          {/* Charts Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <TrendChart />
            <ContentTypeChart />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Index;
